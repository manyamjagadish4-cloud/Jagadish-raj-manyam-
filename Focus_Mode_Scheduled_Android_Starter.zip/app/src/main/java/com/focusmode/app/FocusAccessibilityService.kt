package com.focusmode.app
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock
import java.util.Calendar

class FocusAccessibilityService: AccessibilityService() {
 private var last=0L
 override fun onAccessibilityEvent(e:AccessibilityEvent?) {
  if(e==null || !scheduled()) return
  val pkg=e.packageName?.toString() ?: return
  if(pkg!="com.instagram.android" && pkg!="com.google.android.youtube") return
  val root=rootInActiveWindow ?: return
  val b=StringBuilder(); collect(root,b,0); val t=b.toString().lowercase()
  val block=if(pkg=="com.instagram.android") (t.contains("reels") && t.contains("comment") && (t.contains("share")||t.contains("send"))) else (t.contains("shorts") && t.contains("comment") && (t.contains("subscribe")||t.contains("subscribed")))
  val now=SystemClock.elapsedRealtime()
  if(block && now-last>1400){last=now;performGlobalAction(GLOBAL_ACTION_BACK)}
 }
 private fun scheduled():Boolean {
  val p=getSharedPreferences("focus_mode",MODE_PRIVATE); if(!p.getBoolean("enabled",true))return false
  val c=Calendar.getInstance(); val n=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE)
  val s=p.getInt("sh",9)*60+p.getInt("sm",0); val e=p.getInt("eh",17)*60+p.getInt("em",0)
  if(s==e)return true
  return if(s<e)n in s until e else n>=s || n<e
 }
 private fun collect(n:AccessibilityNodeInfo?,b:StringBuilder,d:Int){if(n==null||d>18)return;n.text?.let{b.append(it).append(' ')};n.contentDescription?.let{b.append(it).append(' ')};for(i in 0 until n.childCount)collect(n.getChild(i),b,d+1)}
 override fun onInterrupt()=Unit
}