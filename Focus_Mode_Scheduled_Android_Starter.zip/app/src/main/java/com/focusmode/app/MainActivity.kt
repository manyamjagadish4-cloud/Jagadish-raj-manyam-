package com.focusmode.app
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
 private val p by lazy { getSharedPreferences("focus_mode", MODE_PRIVATE) }
 private var sh=9; private var sm=0; private var eh=17; private var em=0
 private lateinit var status: TextView
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  sh=p.getInt("sh",9); sm=p.getInt("sm",0); eh=p.getInt("eh",17); em=p.getInt("em",0)
  val l=LinearLayout(this).apply { orientation=1; gravity=Gravity.CENTER; setPadding(28,30,28,30) }
  l.addView(TextView(this).apply { text="Focus Mode"; textSize=30f; gravity=Gravity.CENTER })
  l.addView(TextView(this).apply { text="Block likely Reels and Shorts screens only during your chosen hours. Messaging and normal videos are intended to remain accessible."; textSize=16f; gravity=Gravity.CENTER; setPadding(0,18,0,18) })
  val sw=Switch(this).apply { text="Enable scheduled blocking"; isChecked=p.getBoolean("enabled",true); setOnCheckedChangeListener { _,v -> p.edit().putBoolean("enabled",v).apply(); update() } }
  l.addView(sw)
  status=TextView(this).apply { textSize=18f; gravity=Gravity.CENTER; setPadding(0,18,0,18) }; l.addView(status)
  l.addView(Button(this).apply { text="Set start time"; setOnClickListener { pick(true) } })
  l.addView(Button(this).apply { text="Set end time"; setOnClickListener { pick(false) } })
  l.addView(Button(this).apply { text="Enable Android blocker"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
  l.addView(TextView(this).apply { text="Default schedule: 9:00 AM–5:00 PM. Detection is experimental and may vary with app updates or language."; textSize=13f; gravity=Gravity.CENTER; setPadding(0,20,0,0) })
  setContentView(l); update()
 }
 private fun pick(start:Boolean) {
  TimePickerDialog(this,{_,h,m -> if(start){sh=h;sm=m;p.edit().putInt("sh",h).putInt("sm",m).apply()}else{eh=h;em=m;p.edit().putInt("eh",h).putInt("em",m).apply()};update()},if(start)sh else eh,if(start)sm else em,false).show()
 }
 private fun update() {
  val on=p.getBoolean("enabled",true)
  status.text="Schedule: ${String.format(Locale.getDefault(),"%02d:%02d",sh,sm)} – ${String.format(Locale.getDefault(),"%02d:%02d",eh,em)}\nScheduled blocking: ${if(on)"ON" else "OFF"}"
 }
}