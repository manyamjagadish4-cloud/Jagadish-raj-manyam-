# Focus Mode — scheduled Android starter
Default schedule: 9:00 AM–5:00 PM. The app lets the user change start/end times and switch scheduled blocking on/off.

Build in Android Studio: open this folder, sync Gradle, install Android SDK 35 if requested, connect phone, press Run. Then open Focus Mode, set schedule, tap Enable Android blocker, and enable the service in Android Accessibility settings.

IMPORTANT: This is source code, not an APK. The blocker is experimental. Android has no stable public API to disable only selected buttons inside third-party apps. It checks visible accessibility text and presses Back when it thinks a Reels/Shorts screen is open. UI updates/language may cause missed detections or false positives. Disable the service if it interferes with normal use.

Privacy: no internet permission; visible UI text is checked locally and not transmitted. Accessibility access is powerful; review code before enabling.
